#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# box_cloud_run.py — 箱体云端发版单入口（单包化重构 2026-10-24，工程保障团队）
# 流程：S0 包自检 → S1 一键生成（内部自带刷缓存+引擎两组冻结参数+抽样核对+渲染）→ S2 回传 → S3 自验收
# 每步 try/except 不中断，状态进报告；token 只读 env $T；manifest 逐文件 sha 自检 fail-closed。
import os, sys, json, time, base64, hashlib, subprocess, urllib.request

WORK = "/tmp/kxbox"
REPO = "L125256/box-engine"

# CA 固化三行（与 ea4d825 refresh_cache.py 头部同源，已验证）
os.environ.setdefault('REQUESTS_CA_BUNDLE', '/etc/ssl/certs/ca-certificates.crt')
os.environ.setdefault('SSL_CERT_FILE', '/etc/ssl/certs/ca-certificates.crt')
os.environ.setdefault('CURL_CA_BUNDLE', '')

DEVS = []
def rec(k, v):
    print("[%s] %s" % (k, v), flush=True)
    return v

def gh_api(url, data=None, method=None):
    req = urllib.request.Request(url, data=json.dumps(data).encode() if data is not None else None,
        method=method, headers={"Authorization": "Bearer " + os.environ["T"],
        "Accept": "application/vnd.github+json", "User-Agent": "cloudtask"})
    return json.load(urllib.request.urlopen(req, timeout=60))

def sh(cmd, env=None, timeout=840):
    e = dict(os.environ); e.update(env or {})
    p = subprocess.run(cmd, shell=True, cwd=WORK, env=e, capture_output=True, text=True, timeout=timeout)
    return p.returncode, ((p.stdout or "") + (p.stderr or "")).strip()

def tail(out, n=1, w=170):
    ls = [l for l in out.splitlines() if l.strip()]
    return (ls[-n] if len(ls) >= n else (ls[0] if ls else ""))[:w]

def main():
    os.chdir(WORK)
    # ---- S0 包自检：MANIFEST 逐文件校验（含 eng_final.py 冻结参数件）fail-closed ----
    try:
        n = 0; bad = []
        for line in open("MANIFEST.sha256"):
            h, p = line.split(maxsplit=1); p = p.strip().lstrip("*")
            n += 1
            if not os.path.exists(p) or hashlib.sha256(open(p, "rb").read()).hexdigest() != h:
                bad.append(p)
        if bad:
            raise RuntimeError("manifest 缺/不符: %s" % bad)
        rec("S0-自检", "PASS manifest %d 项全对(eng_final.py sha 锁定在册)" % n)
    except SystemExit:
        raise
    except Exception as e:
        rec("S0-自检", "FAIL %r —— 包损坏 fail-closed 终止" % e); sys.exit(1)

    # ---- S1 一键生成（依赖引导 + BOX_BUILD_DIR=/tmp/kxbox/build）----
    gen = "FAIL"
    try:
        if sh("python3 -c 'import numpy,pandas,requests'")[0] != 0:
            sh("pip3 install -q numpy pandas requests", timeout=300)
        code, out = sh("BOX_BUILD_DIR=/tmp/kxbox/build python3 generate_page.py", timeout=780)
        gen = "code=%d %s" % (code, tail(out))
        rec("S1-生成", gen)
        if code != 0:
            DEVS.append("S1 生成非零退出: " + gen)
    except Exception as e:
        DEVS.append("S1 生成异常: %r" % e); gen = "FAIL %r" % e; rec("S1-生成", gen)

    # ---- S2 回传（box_live.json 与 index.html → 仓库根，内置失败重试1次）----
    up = "FAIL"
    try:
        okall = True; oklist = []
        for rp, lp in [("box_live.json", WORK + "/box_live.json"), ("index.html", WORK + "/index.html")]:
            if not os.path.exists(lp):
                okall = False; DEVS.append("S2 产物缺失 " + rp); continue
            b = base64.b64encode(open(lp, "rb").read()).decode()
            sha = None
            try: sha = gh_api("https://api.github.com/repos/%s/contents/%s?ref=main" % (REPO, rp))["sha"]
            except Exception: pass
            done = False
            for i in range(2):
                try:
                    r = gh_api("https://api.github.com/repos/%s/contents/%s" % (REPO, rp),
                               {"message": "cloud box task: " + rp, "content": b, "branch": "main", "sha": sha}, method="PUT")
                    oklist.append(rp + "@commit=" + r["commit"]["sha"][:10]); done = True; break
                except Exception:
                    time.sleep(30)
                    try: sha = gh_api("https://api.github.com/repos/%s/contents/%s?ref=main" % (REPO, rp))["sha"]
                    except Exception: pass
            if not done:
                okall = False; DEVS.append("S4 PUT_FAIL " + rp)
        up = ("PASS " + " ".join(oklist)) if okall else "FAIL(" + str(len(oklist)) + "/2 成功)"
    except Exception as e:
        DEVS.append("S2 回传异常: %r" % e); up = "FAIL %r" % e
    rec("S2-上传", up)

    # ---- S3 自验收（purge jsDelivr → 30s → API 与 jsDelivr 双通道逐字节比对，复测≤2次）----
    ver = "FAIL"
    try:
        paths = [p for p in ["box_live.json", "index.html"] if os.path.exists(WORK + "/" + p)]
        if not paths:
            ver = "FAIL 无产物文件"; DEVS.append("S3 " + ver)
        else:
            for p in paths:
                try: urllib.request.urlopen("https://purge.jsdelivr.net/gh/%s@main/%s" % (REPO, p), timeout=60).read()
                except Exception: pass
            time.sleep(30)
            allok = True; det = []
            for p in paths:
                tries = 0; ok = False
                while tries < 3:
                    req = urllib.request.Request("https://api.github.com/repos/%s/contents/%s?ref=main" % (REPO, p),
                        headers={"Authorization": "Bearer " + os.environ["T"], "Accept": "application/vnd.github.raw", "User-Agent": "cloudtask"})
                    a = urllib.request.urlopen(req, timeout=60).read()
                    b = urllib.request.urlopen("https://cdn.jsdelivr.net/gh/%s@main/%s" % (REPO, p), timeout=60).read()
                    ok = (a == b) and len(a) >= 100 and len(b) >= 100
                    if ok: break
                    tries += 1; time.sleep(15)
                    try: urllib.request.urlopen("https://purge.jsdelivr.net/gh/%s@main/%s" % (REPO, p), timeout=60).read()
                    except Exception: pass
                allok = allok and ok
                det.append("%s API=%dB jsD=%dB tries=%d %s" % (p, len(a), len(b), tries, "PASS" if ok else "FAIL"))
                if not ok: DEVS.append("S3 验收FAIL " + p)
            ver = ("PASS " + "；".join(det)) if allok else "FAIL " + "；".join(det)
    except Exception as e:
        DEVS.append("S3 验收异常: %r" % e); ver = "FAIL %r" % e
    rec("S3-验收", ver)

    # ---- 固定格式报告 ----
    print()
    print("==== 箱体单入口运行报告 ====")
    print("【箱体发版报告】自检=PASS(manifest全对)｜生成=%s｜上传=%s｜验收=%s｜偏差=%s" % (
        gen, up, ver, ("无" if not DEVS else " / ".join(DEVS))))
    print("红线：本报告不含 $T；eng_final.py 与冻结参数零改动；引擎/数据报错为原文摘录。")

if __name__ == "__main__":
    main()
