#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# f1_cloud_run.py — F1 云端四轮单入口（单包化重构 2026-10-24，工程保障团队）
# 流程：S0 包自检 → S1 状态活拉 → S2 刷缓存 → S3 引擎轮 → S4 回传 → S5 自验收
# 每步 try/except 不中断，状态进报告；token 只读 env $T；主引擎 sha 硬校验 fail-closed。
import os, sys, json, time, base64, hashlib, subprocess, urllib.request

WORK = "/tmp/f1work"
REPO = "L125256/box-engine"
ENGINE_SHA = "92c090044683aff73f5d1193bd4941a001c638578aa0643f55b997eddd8a98f1"
STATE_FILES = [("f1_state.json", "f1_state.json"),                 # (repo_path, local_path) 可变状态三件
               ("f1/forward_state.json", "f1/forward_state.json"),
               ("f1/forward_ic_days.jsonl", "f1/forward_ic_days.jsonl")]

# CA 固化三行（与 ea4d825 refresh_cache.py 头部同源，已验证）
os.environ.setdefault('REQUESTS_CA_BUNDLE', '/etc/ssl/certs/ca-certificates.crt')
os.environ.setdefault('SSL_CERT_FILE', '/etc/ssl/certs/ca-certificates.crt')
os.environ.setdefault('CURL_CA_BUNDLE', '')

DEVS = []   # 偏差收集
def rec(k, v):
    print("[%s] %s" % (k, v), flush=True)
    return v

def gh_api(url, data=None, method=None):
    req = urllib.request.Request(url, data=json.dumps(data).encode() if data is not None else None,
        method=method, headers={"Authorization": "Bearer " + os.environ["T"],
        "Accept": "application/vnd.github+json", "User-Agent": "cloudtask"})
    return json.load(urllib.request.urlopen(req, timeout=60))

def gh_raw(rp, ref="main"):
    req = urllib.request.Request("https://api.github.com/repos/%s/contents/%s?ref=%s" % (REPO, rp, ref),
        headers={"Authorization": "Bearer " + os.environ["T"], "Accept": "application/vnd.github.raw",
        "User-Agent": "cloudtask"})
    return urllib.request.urlopen(req, timeout=60).read()

def sh(cmd, env=None, timeout=840):
    e = dict(os.environ); e.update(env or {})
    p = subprocess.run(cmd, shell=True, cwd=WORK, env=e, capture_output=True, text=True, timeout=timeout)
    return p.returncode, ((p.stdout or "") + (p.stderr or "")).strip()

def tail(out, n=1, w=170):
    ls = [l for l in out.splitlines() if l.strip()]
    return (ls[-n] if len(ls) >= n else (ls[0] if ls else ""))[:w]

def main():
    os.chdir(WORK)
    # ---- S0 包自检：主引擎 sha fail-closed + MANIFEST 逐文件校验 ----
    try:
        engine = hashlib.sha256(open("f1/f1_signal.py", "rb").read()).hexdigest()
        if engine != ENGINE_SHA:
            raise RuntimeError("主引擎 sha 不符: %s" % engine)
        n = 0; bad = []
        for line in open("MANIFEST.sha256"):
            h, p = line.split(maxsplit=1); p = p.strip().lstrip("*")
            n += 1
            if not os.path.exists(p) or hashlib.sha256(open(p, "rb").read()).hexdigest() != h:
                bad.append(p)
        if bad:
            raise RuntimeError("manifest 缺/不符: %s" % bad)
        rec("S0-自检", "PASS 主引擎sha一致 manifest %d 项全对" % n)
    except SystemExit:
        raise
    except Exception as e:
        rec("S0-自检", "FAIL %r —— 包损坏 fail-closed 终止" % e); sys.exit(1)

    # ---- S1 状态活拉：main 三件可变状态 overlay（失败回落包内 vintage，不中断）----
    st = []
    for rp, lp in STATE_FILES:
        try:
            open(lp, "wb").write(gh_raw(rp)); st.append(rp + "=FRESH")
        except Exception as e:
            st.append(rp.split("/")[-1] + "=VINTAGE(%s)" % repr(e)[:48]); DEVS.append("S1 %s 活拉失败用包内vintage" % rp)
    rec("S1-状态活拉", " ".join(st))

    # ---- S2 刷缓存（依赖引导 + 冻结快照解包 D12/S5 + 32线程刷新器）----
    cache_stat = "SKIP"
    try:
        if sh("python3 -c 'import numpy,pandas,requests'")[0] != 0:
            sh("pip3 install -q numpy pandas requests", timeout=300)
        sh("mkdir -p /tmp/box_cache_fresh && tar -xzf engine_snapshot/box_cache_snapshot.tar.gz -C /tmp/box_cache_fresh --strip-components=1")
        code, out = sh("BOX_CACHE_DIR=/tmp/f1work/box_cache BOX_REFRESH_REPORT=/tmp/f1work/refresh_report.json python3 research/wtc/refresh_cache.py", timeout=600)
        try:
            rr = json.load(open("/tmp/f1work/refresh_report.json"))
            cache_stat = "code=%d 成功%s只/失败%s只%s" % (code, rr.get("ok"), rr.get("fail"),
                (" 状态=" + str(rr.get("status"))) if rr.get("status") else "")
        except Exception:
            cache_stat = "code=%d report缺失 末行=%s" % (code, tail(out) or "")
        if code != 0 or "SOURCE-DOWN" in cache_stat or "BUDGET" in cache_stat:
            DEVS.append("S2 刷缓存异常: " + cache_stat)
        rec("S2-刷缓存", cache_stat)
    except Exception as e:
        cache_stat = "FAIL %r" % e; DEVS.append("S2 刷缓存异常: %r" % e); rec("S2-刷缓存", cache_stat)

    # ---- S3 引擎轮（北京时间08点=判定轮 live；其余=快照轮 snapshot，轮次就近映射）----
    mode = None; eng = "FAIL"
    try:
        h = int(sh("TZ=Asia/Shanghai date +%H")[1].strip() or "0")
        mode = os.environ.get("F1_CLOUD_ROUND_OVERRIDE") or ("live" if h == 8 else "snapshot")
        if mode == "live":
            code, out = sh("PYTHONHASHSEED=42 F1_CACHE=/tmp/f1work/box_cache F1_OUT_JSON=/tmp/f1work/f1_live.json SHADOW_BOX_CACHE=/tmp/f1work/box_cache python3 f1/f1_signal.py live")
            eng = "判定轮 code=%d %s" % (code, tail(out))
            rec("S3-引擎", eng)
            if code != 0:
                DEVS.append("S3 判定轮非零退出: " + eng)
            else:
                code2, out2 = sh("PYTHONHASHSEED=42 python3 research/wo_unlock/forward_readout.py --auto")
                fwd = "code=%d %s" % (code2, tail(out2))
                rec("S3-前瞻", fwd)
                if code2 != 0:
                    DEVS.append("S3 前瞻 FORWARD_FAIL_NONBLOCK: " + fwd)
        else:
            r = {"20": "20:30", "0": "00:30", "4": "04:30"}.get(str(h), "20:30")
            code, out = sh("PYTHONHASHSEED=42 F1_CACHE=/tmp/f1work/box_cache F1_OUT_JSON=/tmp/f1work/f1_live_intraday.json SHADOW_BOX_CACHE=/tmp/f1work/box_cache python3 f1/f1_signal.py snapshot --round %s" % r)
            eng = "快照轮 R=%s code=%d %s" % (r, code, tail(out))
            rec("S3-引擎", eng)
            if code != 0:
                DEVS.append("S3 快照轮非零退出: " + eng)
    except Exception as e:
        DEVS.append("S3 引擎异常: %r" % e); rec("S3-引擎", "FAIL %r" % e)

    # ---- S4 回传（contents PUT，只传实际存在产物，内置失败重试1次）----
    up = "FAIL"
    try:
        cand = [("f1/f1_live_intraday.json", WORK + "/f1_live_intraday.json"), ("f1/f1_live.json", WORK + "/f1_live.json"),
                ("f1/shadow_state.json", WORK + "/f1/shadow_state.json"), ("f1/shadow_days.jsonl", WORK + "/f1/shadow_days.jsonl"),
                ("f1/fd_revive_state.json", WORK + "/f1/fd_revive_state.json"), ("f1/fd_revive_days.jsonl", WORK + "/f1/fd_revive_days.jsonl"),
                ("f1/shadow_reg_S1.jsonl", WORK + "/f1/shadow_reg_S1.jsonl"), ("f1/shadow_reg_S2.jsonl", WORK + "/f1/shadow_reg_S2.jsonl"),
                ("f1/shadow_reg_S3.jsonl", WORK + "/f1/shadow_reg_S3.jsonl"), ("f1/enhancement_state.json", WORK + "/f1/enhancement_state.json")]
        fs = [(a, b) for a, b in cand if os.path.exists(b)]
        if os.path.exists(WORK + "/f1_live.json") and os.path.exists(WORK + "/f1_state.json"):
            fs += [("f1/f1_state.json", WORK + "/f1_state.json")]
            for a, b in [("f1/forward_state.json", WORK + "/f1/forward_state.json"), ("f1/forward_ic_days.jsonl", WORK + "/f1/forward_ic_days.jsonl")]:
                if os.path.exists(b): fs += [(a, b)]
        if not fs:
            up = "FAIL 无产物文件"; DEVS.append("S4 " + up)
        else:
            okall = True; oklist = []
            for rp, lp in fs:
                b = base64.b64encode(open(lp, "rb").read()).decode()
                sha = None
                try: sha = gh_api("https://api.github.com/repos/%s/contents/%s?ref=main" % (REPO, rp))["sha"]
                except Exception: pass
                done = False
                for i in range(2):
                    try:
                        r = gh_api("https://api.github.com/repos/%s/contents/%s" % (REPO, rp),
                                   {"message": "cloud f1 round: " + rp, "content": b, "branch": "main", "sha": sha}, method="PUT")
                        oklist.append(rp.split("/")[-1] + "@commit=" + r["commit"]["sha"][:10]); done = True; break
                    except Exception as e:
                        time.sleep(30)
                        try: sha = gh_api("https://api.github.com/repos/%s/contents/%s?ref=main" % (REPO, rp))["sha"]
                        except Exception: pass
                if not done:
                    okall = False; DEVS.append("S4 PUT_FAIL " + rp)
            up = ("PASS " + " ".join(oklist)) if okall else "FAIL(" + str(len(oklist)) + "/" + str(len(fs)) + " 成功)"
    except Exception as e:
        DEVS.append("S4 回传异常: %r" % e); up = "FAIL %r" % e
    rec("S4-上传", up)

    # ---- S5 自验收（purge jsDelivr → 30s → API 与 jsDelivr 双通道逐字节比对，复测≤2次）----
    ver = "FAIL"
    try:
        cand = [("f1/f1_live_intraday.json", WORK + "/f1_live_intraday.json"), ("f1/f1_live.json", WORK + "/f1_live.json"),
                ("f1/f1_state.json", WORK + "/f1_state.json")]
        paths = [p for p, lp in cand if os.path.exists(lp)]
        paths = [p for p in paths if p != "f1/f1_state.json" or os.path.exists(WORK + "/f1_live.json")]
        if not paths:
            ver = "FAIL 无产物文件"; DEVS.append("S5 " + ver)
        else:
            allok = True; det = []
            for p in paths:
                try: urllib.request.urlopen("https://purge.jsdelivr.net/gh/%s@main/%s" % (REPO, p), timeout=60).read()
                except Exception: pass
            time.sleep(30)
            for p in paths:
                tries = 0; ok = False
                while tries < 3:
                    req = urllib.request.Request("https://api.github.com/repos/%s/contents/%s?ref=main" % (REPO, p),
                        headers={"Authorization": "Bearer " + os.environ["T"], "Accept": "application/vnd.github.raw", "User-Agent": "cloudtask"})
                    a = urllib.request.urlopen(req, timeout=60).read()
                    b = urllib.request.urlopen("https://cdn.jsdelivr.net/gh/%s@main/%s" % (REPO, p), timeout=60).read()
                    _min = 50 if p == "f1/f1_state.json" else 100
                    ok = (a == b) and len(a) >= _min and len(b) >= _min
                    if ok: break
                    tries += 1; time.sleep(15)
                    try: urllib.request.urlopen("https://purge.jsdelivr.net/gh/%s@main/%s" % (REPO, p), timeout=60).read()
                    except Exception: pass
                allok = allok and ok
                det.append("%s API=%dB jsD=%dB tries=%d %s" % (p, len(a), len(b), tries, "PASS" if ok else "FAIL"))
                if not ok: DEVS.append("S5 验收FAIL " + p)
            ver = ("PASS " + "；".join(det)) if allok else "FAIL " + "；".join(det)
    except Exception as e:
        DEVS.append("S5 验收异常: %r" % e); ver = "FAIL %r" % e
    rec("S5-验收", ver)

    # ---- 固定格式报告 ----
    print()
    print("==== F1 单入口运行报告 ====")
    print("【F1四轮报告】轮性=%s｜自检=PASS(主引擎sha一致,manifest全对)｜状态活拉=%s｜缓存=%s｜引擎=%s｜上传=%s｜验收=%s｜偏差=%s" % (
        mode or "unknown", st, cache_stat, eng, up, ver, ("无" if not DEVS else " / ".join(DEVS))))
    print("红线：本报告不含 $T；引擎/数据报错为原文摘录。")

if __name__ == "__main__":
    main()
